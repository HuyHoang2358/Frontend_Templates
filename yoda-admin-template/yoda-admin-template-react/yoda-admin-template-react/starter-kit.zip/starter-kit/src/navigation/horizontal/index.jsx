import pages from "./pages";

const navigation = [...pages];

export default navigation