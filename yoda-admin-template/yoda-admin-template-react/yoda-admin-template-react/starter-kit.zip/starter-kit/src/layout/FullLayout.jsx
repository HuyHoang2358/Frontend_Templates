export default function FullLayout({ children }) {
  return children;
};