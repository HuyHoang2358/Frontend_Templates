// Routes Imports
import Pages from "./Pages";

// Merge Routes
const Routes = [...Pages];

export { Routes };