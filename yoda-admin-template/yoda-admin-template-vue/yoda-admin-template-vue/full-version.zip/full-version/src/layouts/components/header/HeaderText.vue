<template>
  <div
    class="hp-header-text-info col col-lg-14 col-xl-16 hp-header-start-text d-flex align-items-center"
  >
    <div
      class="overflow-hidden hp-bg-black-0 hp-bg-dark-100 d-flex"
      style="min-width: 45px; width: 45px; height: 45px; border-radius: 15px"
    >
      <img
        :src="require('@/assets/img/memoji/newspaper.svg')"
        alt="Newspaper"
        height="80%"
        style="margin-top: auto; margin-left: auto"
      />
    </div>

    <p
      class="hp-header-start-text-item hp-input-label font-weight-normal hp-text-color-black-100 hp-text-color-dark-0 ml-12 mb-0 lh-1"
    >
      Do you know the latest update of 2022?&nbsp;
      <a href="https://trello.com/b/8ZRmDN5y/yoda-roadmap" target="_blank" class="hp-text-color-primary-1">
        Our roadmap is alive for future updates.
      </a>
    </p>
  </div>
</template>
